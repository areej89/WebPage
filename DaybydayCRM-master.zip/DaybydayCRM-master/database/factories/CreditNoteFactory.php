<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\CreditNote;
use Faker\Generator as Faker;

$factory->define(CreditNote::class, function (Faker $faker) {
    return [
        //
    ];
});
