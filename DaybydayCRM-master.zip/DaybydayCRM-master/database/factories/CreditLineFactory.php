<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\CreditLine;
use Faker\Generator as Faker;

$factory->define(CreditLine::class, function (Faker $faker) {
    return [
        //
    ];
});
