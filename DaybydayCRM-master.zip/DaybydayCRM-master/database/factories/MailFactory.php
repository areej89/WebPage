<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\Mail;
use Faker\Generator as Faker;

$factory->define(Mail::class, function (Faker $faker) {
    return [
        //
    ];
});
