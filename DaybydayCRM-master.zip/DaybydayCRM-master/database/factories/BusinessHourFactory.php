<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\BusinessHour;
use Faker\Generator as Faker;

$factory->define(BusinessHour::class, function (Faker $faker) {
    return [
        //
    ];
});
